library(testthat)
library(cgmguru)

test_check("cgmguru")

