#ifndef UTILS_H
#define UTILS_H

#include <string>

// Utility functions
std::string format_timestamp(double timestamp);

#endif // UTILS_H
