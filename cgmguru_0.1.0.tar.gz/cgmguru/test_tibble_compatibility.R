# Test script to verify tibble compatibility
library(cgmguru)

# Create sample data
set.seed(123)
n <- 100
dataset <- data.frame(
  id = rep(c("A", "B"), each = n/2),
  time = as.POSIXct(seq(as.POSIXct("2023-01-01"), by = "5 min", length.out = n)),
  gl = rnorm(n, mean = 120, sd = 20)
)

# Convert to tibble
dataset <- tibble::as_tibble(dataset)

# Test the workflow with tibble compatibility
cat("Testing tibble compatibility...\n")

# 1) Find GRID points
cat("1. Running grid()...\n")
grid_result <- grid(dataset, gap = 15, threshold = 130)
print(paste("Grid result type:", class(grid_result)))
print(paste("GRID_vector type:", class(grid_result$GRID_vector)))

# 2) Find modified GRID points before 2 hours minimum
cat("2. Running mod_grid()...\n")
mod_grid_result <- mod_grid(dataset, 
                           grid_result$GRID_vector,  # Now passing tibble
                           hours = 2, 
                           gap = 15)
print(paste("Mod grid result type:", class(mod_grid_result)))
print(paste("modGRID_vector type:", class(mod_grid_result$modGRID_vector)))

# 3) Find maximum point 2 hours after mod_grid point
cat("3. Running find_max_after_hours()...\n")
mod_grid_maxima <- find_max_after_hours(dataset, 
                                       mod_grid_result$modGRID_vector,  # Now passing tibble
                                       hours = 2)
print(paste("Mod grid maxima result type:", class(mod_grid_maxima)))
print(paste("max_indices type:", class(mod_grid_maxima$max_indices)))

# 4) Identify local maxima around episodes/windows
cat("4. Running find_local_maxima()...\n")
local_maxima <- find_local_maxima(dataset)
print(paste("Local maxima result type:", class(local_maxima)))
print(paste("local_maxima_vector type:", class(local_maxima$local_maxima_vector)))

# 5) Among local maxima, find maximum point after two hours
cat("5. Running find_new_maxima()...\n")
final_maxima <- find_new_maxima(dataset, 
                               mod_grid_maxima$max_indices,  # Now passing tibble
                               local_maxima$local_maxima_vector)  # Now passing tibble
print(paste("Final maxima result type:", class(final_maxima)))

# 6) Map GRID points to maximum points (within 4 hours)
cat("6. Running transform_df()...\n")
transform_maxima <- transform_df(grid_result$episode_start_total, final_maxima)
print(paste("Transform maxima result type:", class(transform_maxima)))

# 7) Redistribute overlapping maxima between GRID points
cat("7. Running detect_between_maxima()...\n")
final_between_maxima <- detect_between_maxima(dataset, transform_maxima)
print(paste("Final between maxima result type:", class(final_between_maxima)))

cat("\nAll tests completed successfully! The functions now work with tibble inputs.\n")
