# Debug script to check grid output structure
library(cgmguru)

# Create sample data
set.seed(123)
n <- 100
dataset <- data.frame(
  id = rep(c("A", "B"), each = n/2),
  time = as.POSIXct(seq(as.POSIXct("2023-01-01"), by = "5 min", length.out = n)),
  gl = rnorm(n, mean = 120, sd = 20)
)

# Convert to tibble
dataset <- tibble::as_tibble(dataset)

# Test grid function
grid_result <- grid(dataset, gap = 15, threshold = 130)

# Check the structure
cat("Grid result structure:\n")
str(grid_result)

cat("\nGRID_vector structure:\n")
str(grid_result$GRID_vector)

cat("\nGRID_vector column names:\n")
print(colnames(grid_result$GRID_vector))

cat("\nGRID_vector first few rows:\n")
print(head(grid_result$GRID_vector))
